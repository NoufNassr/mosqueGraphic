package org.yourorghere;

import com.sun.opengl.util.Animator;
import com.sun.opengl.util.GLUT;
import com.sun.opengl.util.texture.Texture;
import com.sun.opengl.util.texture.TextureIO;
import java.awt.Frame;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.media.opengl.GL;
import static javax.media.opengl.GL.GL_BLEND;
import static javax.media.opengl.GL.GL_DEPTH_TEST;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.GLException;
import javax.media.opengl.glu.GLU;




public class MasjedGraphic implements GLEventListener, KeyListener {
    double angle = 0.0;
    Texture tex;
    double TIMER = 0;
    // Vector representing the camera's initial direction
static float cameraX = 0f, cameraY = 3f, cameraZ = 7;
// Vector initial position of the camera
static float locationX = 0, locationY = 2, locationZ = -5;

    public static void main(String[] args) {
        Frame frame = new Frame("Simple JOGL Application");
        GLCanvas canvas = new GLCanvas();

        canvas.addGLEventListener(new MasjedGraphic());
        frame.add(canvas);
        frame.setSize(640, 480);
         KeyListener listener = new KeyListener() {

            @Override

            public void keyPressed(KeyEvent event) {

                System.out.println("KEY EVENT ENTERED.");
                // Locations ----------------------
                if (event.getKeyCode() == KeyEvent.VK_LEFT) {
                    System.out.println("KEY EVENT LEFT.");
                    locationX--;
                }
                if (event.getKeyCode() == KeyEvent.VK_DOWN) {
                    System.out.println("KEY EVENT DOWN.");
                    locationY--;
                }
                if (event.getKeyCode() == KeyEvent.VK_RIGHT) {
                    System.out.println("KEY EVENT RIGHT.");
                    locationX++;
                }
                if (event.getKeyCode() == KeyEvent.VK_UP) {
                    System.out.println("KEY EVENT UP.");
                    locationY++;
                }

                // Locations ----------------------
                if (event.getKeyCode() == KeyEvent.VK_A) {
                    System.out.println("KEY EVENT A.");
                    cameraX--;
                }
                if (event.getKeyCode() == KeyEvent.VK_S) {
                    System.out.println("KEY EVENT S.");
                    cameraZ--;
                }
                if (event.getKeyCode() == KeyEvent.VK_D) {
                    System.out.println("KEY EVENT D.");
                    cameraX++;
                }
                if (event.getKeyCode() == KeyEvent.VK_W) {
                    System.out.println("KEY EVENT W.");
                    cameraZ++;
                }

            }

            @Override

            public void keyReleased(KeyEvent event) {

                //printEventInfo("Key Released", event);
            }

            @Override

            public void keyTyped(KeyEvent event) {

                printEventInfo("Key Typed", event);

            }

            private void printEventInfo(String str, KeyEvent e) {

                System.out.println(str);

                int code = e.getKeyCode();

                System.out.println("   Code: " + KeyEvent.getKeyText(code));

                System.out.println("   Char: " + e.getKeyChar());

                int mods = e.getModifiersEx();

                System.out.println("    Mods: "
                        + KeyEvent.getModifiersExText(mods));

                System.out.println("    Location: "
                        + keyboardLocation(e.getKeyLocation()));

                System.out.println("    Action? " + e.isActionKey());

            }

            private String keyboardLocation(int keybrd) {

                switch (keybrd) {

                    case KeyEvent.KEY_LOCATION_RIGHT:

                        return "Right";

                    case KeyEvent.KEY_LOCATION_LEFT:

                        return "Left";

                    case KeyEvent.KEY_LOCATION_NUMPAD:

                        return "NumPad";

                    case KeyEvent.KEY_LOCATION_STANDARD:

                        return "Standard";

                    case KeyEvent.KEY_LOCATION_UNKNOWN:

                    default:

                        return "Unknown";

                }

            }

        };
canvas.addKeyListener(listener);
        // End of Detecting Pressed Keys ----------------------------------------------------
        final Animator animator = new Animator(canvas);
        frame.addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                // Run this on another thread than the AWT event queue to
                // make sure the call to Animator.stop() completes before
                // exiting
                new Thread(new Runnable() {

                    public void run() {
                        animator.stop();
                        System.exit(0);
                    }
                }).start();
            }
        });
        // Center frame
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        animator.start();
    }

    public void init(GLAutoDrawable drawable) {
        // Use debug pipeline
        // drawable.setGL(new DebugGL(drawable.getGL()));

        GL gl = drawable.getGL();
        System.err.println("INIT GL IS: " + gl.getClass().getName());

        // Enable VSync
        gl.setSwapInterval(1);

        // Setup the drawing area and shading mode
        gl.glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
        gl.glShadeModel(GL.GL_FLAT); // try setting this to GL_FLAT and see what happens.
    }

    public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
        GL gl = drawable.getGL();
        GLU glu = new GLU();

        if (height <= 0) { // avoid a divide by zero error!
        
            height = 1;
        }
        final float h = (float) width / (float) height;
        gl.glViewport(0, 0, width, height);
        gl.glMatrixMode(GL.GL_PROJECTION);
        gl.glLoadIdentity();
        glu.gluPerspective(45.0f, h, 1.0, 20.0);
        gl.glMatrixMode(GL.GL_MODELVIEW);
        gl.glLoadIdentity();
    }

    public void display(GLAutoDrawable drawable) {
        
        GL gl = drawable.getGL();
        GLUT glut = new GLUT();

        // Clear the drawing area
        gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
        // Reset the current matrix to the "identity"
        gl.glLoadIdentity();
        
        
        // Lighting ----------------------------------------------------------------
        // Turning on the light comonents
        gl.glEnable(GL.GL_LIGHTING);
        gl.glEnable(GL.GL_LIGHT0);
        gl.glEnable(GL.GL_NORMALIZE);
        gl.glShadeModel(GL.GL_SMOOTH);
        gl.glEnable(GL.GL_COLOR_MATERIAL);

//         Setting different light parameters
        float[] ambientLight = {0.5f,0.5f, 0.5f, 0f};  // weak white ambient 
        gl.glLightfv(GL.GL_LIGHT0, GL.GL_AMBIENT, ambientLight, 0);

        float[] diffuseLight = {0.5f, 0.5f, 0.5f, 0f};  // multicolor diffuse 
        gl.glLightfv(GL.GL_LIGHT0, GL.GL_DIFFUSE, diffuseLight, 0);
        
        float[] positionLight = {-3f, 2f, 0f};  // coordinates of the light
        gl.glLightfv(GL.GL_LIGHT0, GL.GL_POSITION, positionLight, 0);
//        
//        float[] specularLight = {10.0f, 10.0f, 10.0f, 10.0f}; // intensety of the shine
//        gl.glLightfv(GL.GL_LIGHT0, GL.GL_SPECULAR, specularLight, 0);
        
              GLU glu = new GLU();
//              glu.gluLookAt(cameraX, cameraY, cameraZ, //  position of your camera
//              locationX , locationY , locationZ , // where the camera is looking at
//              0.0f, 1.0f, 0.0f); // tilt of camera (unchanged)
//              glu.gluLookAt(0, 1, 3, //  position of your camera
                      glu.gluLookAt(cameraX, cameraY, cameraZ,
              locationX , locationY , locationZ , // where the camera is looking at

//              0 , 0 , 0 , // where the camera is looking at
              0.0f, 1.0f, 0.0f); // tilt of camera (unchanged)
// End of setting the camera -------------------------------------------------
        
//        
//      gl.glColor3f(1f, 0, 0);
//      gl.glBegin(GL.GL_LINES);
//      gl.glVertex3f(0,5,0);
//      gl.glVertex3f(0,-5,0);
//      gl.glVertex3f(-5,0,0);  
//      gl.glVertex3f(5,0,0);
//      gl.glEnd();
        
      
//        gl.glTranslatef(-0.8f, 0.2f, 0.5f);
//        gl.glPushMatrix();
//        gl.glScalef(0.7f, 0.7f, 0.7f);
//        gl.glRotated(angle, 0, 1, 0);
//        
////        gl.glRotatef(-90, 0, 1, 0);
//        MasjedNew(glut, gl);
//        gl.glPopMatrix();
//        angle+=1;
        
        gl.glPushMatrix();
//        gl.glEnable( GL_DEPTH_TEST );

        gl.glTranslatef(2.5f,2.5f,0); // 3. Translate to the object's position.

        gl.glRotatef((float)angle,0,1,0); // 2. Rotate the object.

        gl.glTranslatef(-2.5f,-2.5f,0f); // 1. Translate to the origin.

        gl.glScalef(1f, 1f, 1f);
        MasjedNew(glut, gl);
        gl.glPopMatrix();
        angle+=0.5;
        
        
        // Draw the object

        // Flush all drawing operations to the graphics card
        gl.glFlush();
    }

    public void MasjedNew(GLUT glut, GL gl){
    
    gl.glPushMatrix();
    
    gl.glTranslatef(2f, 0.0f, 0f);
    //gl.glRotatef(60, 0, 1, 0);
    gl.glScalef(0.5f, 0.5f, 0.5f);
    
    Qubba(glut, gl);
    Methana(glut, gl);
    bulding(glut, gl);
    gl.glPopMatrix();
    
    
    
    
    }
    
    
    
    public void Qubba(GLUT glut, GL gl){
    
    gl.glPushMatrix();//start all
    gl.glTranslatef(0f, 0.5f, 0f);
    //gl.glRotatef(angle, 0, 0, 0);
    
    //cylinder
    gl.glPushMatrix();
    gl.glTranslatef(0f, 1.2f, -2.0f);
    gl.glRotatef(90, 1, 0, 0);
    //gl.glScalef(1, 1.7f, 1);
    gl.glColor3f(0.643f, 0.647f, 0.662f);
        
    glut.glutSolidCylinder(0.015, 0.2, 20, 20);//thing
    gl.glPopMatrix();//----end 1
    //sphere
    gl.glPushMatrix();
    gl.glTranslatef(0f, -0.2f, -2f);
    gl.glScalef(1f, 1f, 1f);
    gl.glColor3f(1f, 0.741f, 0.2f);
    //gl.glRotatef(angle, x, y, z);
    
    glut.glutSolidSphere(1.2f,20,20);//thing
    
    gl.glPopMatrix();//end 1
 
    //-------------------------------------------------------
    
    //cylinder
    gl.glPushMatrix();
    gl.glTranslatef(0f, 0.0f, -2.0f);
    gl.glRotatef(90, 1, 0, 0);
    //gl.glScalef(1, 1.7f, 1);
    gl.glColor3f(0.643f, 0.647f, 0.662f);
        
    glut.glutSolidCylinder(1.3, 0.5, 10, 5);//thing
    
    
    gl.glPopMatrix();//----end 2
    
    gl.glPopMatrix();//end all
    
    
    }
    public void bulding(GLUT glut, GL gl){
    
    gl.glPushMatrix();//start all
    gl.glTranslatef(0f, -1.0f, 0.0f);
    //gl.glRotatef(40, 0, 1, 0);
    
    
    
    
    //bulding
    gl.glPushMatrix();
    
    gl.glEnable( GL_DEPTH_TEST );
    gl.glTranslatef(0f, 0.0f, -2f);
    //gl.glRotatef(angle, x, y, z);
    gl.glScalef(2.2f, 1.03f, 1.5f);
    gl.glColor3f(241/255f, 239/255f, 240/255f);
    
    glut.glutSolidCube(2);//thing
    
    gl.glPopMatrix();//end 1
    
    
    //bulding roof1
    gl.glPushMatrix();
    gl.glTranslatef(0f, 1.0f, -2f);
    //gl.glRotatef(angle, x, y, z);
    gl.glScalef(2.2f, 0.1f, 1.5f);
    gl.glColor3f(241/255f, 239/255f, 240/255f);
    
    glut.glutSolidCube(2.2f);//thing
    
    gl.glPopMatrix();//end 2
    
    
    //bulding roof2
    gl.glPushMatrix();
    gl.glTranslatef(0f, 1.2f, -2f);
    //gl.glRotatef(angle, x, y, z);
    gl.glScalef(2.2f, 0.1f, 1.5f);
    gl.glColor3f(98/255f, 195/255f, 237/255f);
    
    glut.glutSolidCube(2.0f);//thing
    
    gl.glPopMatrix();//end 4
 
    //-------------------------------------------------------
    
    //bulding column 1 
    gl.glPushMatrix();
    gl.glTranslatef(2.3f, -0.06f, -0.4f);
    //gl.glRotatef(angle, x, y, z);
    gl.glScalef(1.5f, 19f, 1.2f);
    gl.glColor3f(98/255f, 195/255f, 237/255f);
    
    glut.glutSolidCube(0.1f);//thing
    gl.glPopMatrix();//end column 1 
    //---------------------------------
     //bulding column 2 
    gl.glPushMatrix();
    gl.glTranslatef(-2.3f, -0.06f, -0.4f);
    //gl.glRotatef(angle, x, y, z);
    gl.glScalef(1.5f, 19f, 1.2f);
    gl.glColor3f(98/255f, 195/255f, 237/255f);
    
    glut.glutSolidCube(0.1f);//thing
    gl.glPopMatrix();//end column 2 
    //---------------------------------
    
    //bulding column 3 
    gl.glPushMatrix();
    gl.glTranslatef(2.3f, -0.06f, -3.6f);
    //gl.glRotatef(angle, x, y, z);
    gl.glScalef(1.5f, 19f, 1.2f);
    gl.glColor3f(98/255f, 195/255f, 237/255f);
    
    glut.glutSolidCube(0.1f);//thing
    gl.glPopMatrix();//end column 3 
    //---------------------------------
    
     //bulding column 4 
    gl.glPushMatrix();
    gl.glTranslatef(-2.3f, -0.06f, -3.6f);
    //gl.glRotatef(angle, x, y, z);
    gl.glScalef(1.5f, 19f, 1.2f);
    gl.glColor3f(98/255f, 195/255f, 237/255f);
    
    glut.glutSolidCube(0.1f);//thing
    gl.glPopMatrix();//end column 4 
    //---------------------------------
    
    //bulding column 1 side
    gl.glPushMatrix();
    gl.glTranslatef(3.55f, -0.1f, -1.8f);
    //gl.glRotatef(angle, x, y, z);
    gl.glScalef(1.5f, 19.2f, 1.2f);
    gl.glColor3f(98/255f, 195/255f, 237/255f);
    
    glut.glutSolidCube(0.1f);//thing
    gl.glPopMatrix();//end column 1 side 
    //---------------------------------
    //bulding column 1 side
    gl.glPushMatrix();
    gl.glTranslatef(3.55f, -0.1f, -3.4f);
    //gl.glRotatef(angle, x, y, z);
    gl.glScalef(1.5f, 19.2f, 1.2f);
    gl.glColor3f(98/255f, 195/255f, 237/255f);
    
    glut.glutSolidCube(0.1f);//thing
    gl.glPopMatrix();//end column 1 side 
    //----------------------------------
    
    
    
    
        gl.glPushMatrix();
        gl.glTranslatef(0f, 0f, -3.15f);
        //gl.glRotatef(-60, 0, 1, 1);
        //gl.glScalef(0.3f, 0.3f, 0f);
        // start all windowBigs behind
        
       
        //windowBig2
        gl.glPushMatrix();
        gl.glTranslatef(1.3f, 0.35f, -0.4f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.8f, 0.7f, 0f);
        windowBig(glut, gl);
        gl.glPopMatrix();
        //---------------------------
        
        
        //windowBig4
        gl.glPushMatrix();
        gl.glTranslatef(0.0f, 0.35f, -0.4f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.8f, 0.7f, 0f);
        windowBig(glut, gl);
        gl.glPopMatrix();
        //---------------------------
        
        //windowBig6
        gl.glPushMatrix();
        gl.glTranslatef(-1.3f, 0.35f, -0.4f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.8f, 0.7f, 0f);
        windowBig(glut, gl);
        gl.glPopMatrix();
        //---------------------------
        //windowBig2 frame
        gl.glPushMatrix();
        gl.glTranslatef(1.3f, 0.35f, -0.38f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.85f, 0.73f, 0f);
        windowBigFrame(glut, gl);
        gl.glPopMatrix();
        //---------------------------
        
        
        //windowBig4 frame
        gl.glPushMatrix();
        gl.glTranslatef(0.0f, 0.35f, -0.38f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.85f, 0.73f, 0f);
        windowBigFrame(glut, gl);
        gl.glPopMatrix();
        //---------------------------
        
        //windowBig6 frame
        gl.glPushMatrix();
        gl.glTranslatef(-1.3f, 0.35f, -0.38f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.85f, 0.73f, 0f);
        windowBigFrame(glut, gl);
        gl.glPopMatrix();
        //---------------------------
        
        gl.glPopMatrix();
        // end windowBigs behind -----------------------------------------
        
        gl.glPushMatrix();
        gl.glTranslatef(0f, 0f, 0f);
        //gl.glRotatef(-60, 0, 1, 1);
        //gl.glScalef(0.3f, 0.3f, 0f);
        // start all windows infront
        
       //window1
        gl.glPushMatrix();
        gl.glTranslatef(1.5f, 0.5f, -0.4f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.3f, 0.3f, 0f);
        window(glut, gl);
        gl.glPopMatrix();
        //---------------------------
        //window1 frame
        gl.glPushMatrix();
        gl.glTranslatef(1.5f, 0.5f, -0.42f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.35f, 0.33f, 0f);
        windowframe(glut, gl);
        gl.glPopMatrix();
        //---------------------------

        //window3
        gl.glPushMatrix();
        gl.glTranslatef(0.5f, 0.5f, -0.4f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.3f, 0.3f, 0f);
        window(glut, gl);
        gl.glPopMatrix();
        //---------------------------
        //window3 frame
        gl.glPushMatrix();
        gl.glTranslatef(0.5f, 0.5f, -0.42f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.35f, 0.33f, 0f);
        windowframe(glut, gl);
        gl.glPopMatrix();
        //---------------------------

        //window5
        gl.glPushMatrix();
        gl.glTranslatef(-0.5f, 0.5f, -0.4f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.3f, 0.3f, 0f);
        window(glut, gl);
        gl.glPopMatrix();
        //---------------------------
        //window5 frame
        gl.glPushMatrix();
        gl.glTranslatef(-0.5f, 0.5f, -0.42f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.35f, 0.33f, 0f);
        windowframe(glut, gl);
        gl.glPopMatrix();
        //---------------------------

        //window7
        gl.glPushMatrix();
        gl.glTranslatef(-1.5f, 0.5f, -0.4f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.3f, 0.3f, 0f);
        window(glut, gl);
        gl.glPopMatrix();
        //---------------------------
        //window7 frame
        gl.glPushMatrix();
        gl.glTranslatef(-1.5f, 0.5f, -0.42f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.35f, 0.33f, 0f);
        windowframe(glut, gl);
        gl.glPopMatrix();
        //---------------------------
        gl.glPopMatrix();
        // end windows infront -----------------------------------------
        
        
        
        gl.glPushMatrix();
        gl.glTranslatef(-1.85f, -0.2f, -1.7f);
        gl.glRotatef(90, 0, 1, 0);
        //gl.glScalef(0.3f, 0.3f, 0f);
        // ------------------------ start all windows side1
        
        //window2 frame
        gl.glPushMatrix();
        gl.glTranslatef(1.0f, 0.5f, -0.4f);
//        gl.glColor3f(98/255f, 195/255f, 237/255f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.55f, 0.5f, 0f);
        windowBigFrame(glut, gl);
        gl.glPopMatrix();
        //---------------------------
        
        //window4 frame
        gl.glPushMatrix();
        gl.glTranslatef(-0.2f, 0.5f, -0.4f);
//        gl.glColor3f(98/255f, 195/255f, 237/255f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.55f, 0.5f, 0f);
        windowBigFrame(glut, gl);
        gl.glPopMatrix();
        //---------------------------

        //window2
        gl.glPushMatrix();
        gl.glTranslatef(1.0f, 0.5f, -0.42f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.5f, 0.45f, 0f);
        windowBig(glut, gl);
        gl.glPopMatrix();
        //---------------------------
        
        //window4
        gl.glPushMatrix();
        gl.glTranslatef(-0.2f, 0.5f, -0.42f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.5f, 0.45f, 0f);
         gl.glColor3f(98/255f, 195/255f, 237/255f);
        windowBig(glut, gl);
         gl.glColor3f(98/255f, 195/255f, 237/255f);
        gl.glPopMatrix();
        //---------------------------
        
       
        gl.glPopMatrix();
        // end windows side1 -----------------------------------------
        
        

        
        
        
    
    //entrance1
    gl.glPushMatrix();
    gl.glTranslatef(0.0f, -0.5f, -0.4f);
    //gl.glRotatef(angle, x, y, z);
    gl.glScalef(1.3f, 1f, 0.3f);
    //gl.glColor3f(0.901f, 0.901f, 0.909f);
    gl.glColor3f(0.643f, 0.647f, 0.662f);
    
    glut.glutSolidCube(1);//thing
    
    gl.glPopMatrix();//----end 2
    
    //entrance2
    gl.glPushMatrix();
    gl.glTranslatef(2.8f, -0.08f, -2.6f);
    gl.glRotatef(90, 0, 1, 0);
    gl.glScalef(1.0f, 1.34f, 1f);
    //gl.glColor3f(0.901f, 0.901f, 0.909f);
    gl.glColor3f(241/255f, 239/255f, 240/255f);
    glut.glutSolidCube(1.45f);//thing
    
    gl.glPopMatrix();//----end 2
    
    
    gl.glColor3f(241/255f, 239/255f, 240/255f);
    
    //entrance  2 roof
    gl.glPushMatrix();
    gl.glTranslatef(2.8f, 0.95f, -2.6f);
    gl.glRotatef(90, 0, 1, 0);
    gl.glScalef(1.0f, 0.11f, 1f);
    //gl.glColor3f(0.901f, 0.901f, 0.909f);
    gl.glColor3f(241/255f, 239/255f, 240/255f);
    glut.glutSolidCube(1.7f);//thing
    
    gl.glPopMatrix();//----end 2
    
    
       //door entrance
        gl.glPushMatrix();
        gl.glTranslatef(3.55f, 0.28f, -2.55f);
        gl.glRotatef(90, 0, 1, 0);
        gl.glScalef(1f, 0.75f, 1f);
        door(glut, gl);
        gl.glPopMatrix();
        //---------------------------
        
    
    
    
    //--------------------------------------------------------
    
    //door
    
        gl.glPushMatrix();//start all
        gl.glTranslatef(0f, -0.3f, -0.24f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.6f, 0.4f, 0.1f);
        door(glut, gl);
        gl.glPopMatrix();
        
    //----------------------------------------------
    
    gl.glPopMatrix();//end all
    }
    
    public void Methana(GLUT glut, GL gl){
    
    gl.glPushMatrix();//start all
    gl.glTranslatef(-1.3f, 2.4f, -1.8f);
    //gl.glRotatef(-60, 0, 1, 1);
    gl.glScalef(0.2f, 0.2f, 0.2f);
    
    
    gl.glPushMatrix();
    gl.glTranslatef(0f, 2f, -2.0f);
    //gl.glRotatef(90, 1, 0, 0);
    
    
    
    //cylinder
    gl.glPushMatrix();
    gl.glTranslatef(-2f, 0f, -2.0f);
    gl.glRotatef(90, 1, 0, 0);
    //gl.glScalef(1, 1.7f, 1);
    gl.glColor3f(0.643f, 0.647f, 0.662f);
        
    glut.glutSolidCylinder(0.05, 0.3, 20, 20);//thing
    gl.glPopMatrix();//----end 1
    
    //cylinder
    gl.glPushMatrix();
    gl.glTranslatef(-2f, -0.3f, -2.0f);
    gl.glRotatef(90, 1, 0, 0);
    //gl.glScalef(1, 1.7f, 1);
    gl.glColor3f(0.643f, 0.647f, 0.662f);
        
    glut.glutSolidCylinder(0.1, 5, 20, 20);//thing
    gl.glPopMatrix();//----end 2
    
    //sphere
    gl.glPushMatrix();
    gl.glTranslatef(-2f, -2f, -2f);
    //gl.glScalef(1f, 1f, 1f);
    gl.glColor3f(1f, 0.741f, 0.2f);
    //gl.glRotatef(angle, x, y, z);
    
    glut.glutSolidSphere(1.4f,20,20);//thing
    
    gl.glPopMatrix();//end 3
    
    
    gl.glPopMatrix();
 
    //-------------------------------------------------------
    
    
    gl.glPushMatrix();//start all
    gl.glTranslatef(-2f, 0f, -2f);
    //gl.glRotatef(angle, 0, 0, 0);
    //gl.glScalef(0.2f, 0.2f, 0.2f);
    //cylinder
    gl.glPushMatrix();
    gl.glTranslatef(0f, -1f, -2.0f);
    gl.glRotatef(90, 1, 0, 0);
    //gl.glScalef(1, 1.7f, 1);
    gl.glColor3f(0.643f, 0.647f, 0.662f);
        
    glut.glutSolidCylinder(1, 2, 10, 5);//thing
    
    
    gl.glPopMatrix();//----end 1
    
    //-------------------------------------------------------
    
    //cylinder
    gl.glPushMatrix();
    gl.glTranslatef(0f, -3.5f, -2.0f);
    gl.glRotatef(90, 1, 0, 0);
    //gl.glScalef(1, 1.7f, 1);
    gl.glColor3f(0.643f, 0.647f, 0.662f);
        
    glut.glutSolidTorus(0.5, 2, 3, 20);//thing
    
    
    gl.glPopMatrix();//----end 2
    
    
    //-------------------------------------------------------
    
    //cylinder
    gl.glPushMatrix();
    gl.glTranslatef(0f, -4.0f, -2.0f);
    gl.glRotatef(90, 1, 0, 0);
    //gl.glScalef(1, 1.7f, 1);
    gl.glColor3f(0.643f, 0.647f, 0.662f);
        
    glut.glutWireCylinder(1.3f, 3, 8, 0);//thing Wire object
    
    
    gl.glPopMatrix();//----end 3
    
    //-------------------------------------------------------
    
    //-------------------------------------------------------
    
    //cylinder
    gl.glPushMatrix();
    gl.glTranslatef(0f, -7.0f, -2.0f);
    gl.glRotatef(90, 1, 0, 0);
    gl.glScalef(1, 1.7f, 1);
    gl.glColor3f(0.643f, 0.647f, 0.662f);
        
    glut.glutSolidCylinder(2.3, 1.5, 20, 10);//thing
    
    
    gl.glPopMatrix();//----end 4
    
    //cylinder
    gl.glPushMatrix();
    gl.glTranslatef(0f, -7.5f, -2.0f);
    gl.glRotatef(90, 1, 0, 0);
    //gl.glScalef(1, 1.7f, 1);
    gl.glColor3f(0.643f, 0.647f, 0.662f);
        
    glut.glutSolidCylinder(1.7, 13, 10, 5);//thing
    
    
    gl.glPopMatrix();//----end 5
    
    gl.glPopMatrix();//end cylinder
    
    gl.glPopMatrix();//end all
    
    
    }
    
    
    public void door(GLUT glut, GL gl){
    
        gl.glPushMatrix();//start all
        gl.glTranslatef(0f, 0f, 0f);
        //gl.glRotatef(-120, 0, 1, 0);
        //gl.glScalef(0.2f, 0.2f, 0.2f);
        //----------------------------------------------------------
        
        gl.glPushMatrix();//start all
        gl.glTranslatef(0f, 0f, 0f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(1f, 1f, 0f);
        //gl.glColor3f(0.901f, 0.901f, 0.909f);
        //gl.glColor3f(0.643f, 0.647f, 0.662f);
        gl.glColor3f(2/255f, 56/255f, 80/255f);
        glut.glutSolidSphere(0.6, 20, 10);//object
        gl.glPopMatrix();
        
        //-------------------------------------
        
        gl.glPushMatrix();//start all
        gl.glTranslatef(0f, -1.0f, 0f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(1f, 1.3f, 0f);
        //gl.glColor3f(0.901f, 0.901f, 0.909f);
        //gl.glColor3f(0.643f, 0.647f, 0.662f);
        gl.glColor3f(2/255f, 56/255f, 80/255f);
        glut.glutSolidCube(1.2f);//object
        gl.glPopMatrix();
        
        //---------------------------------------
        
        
        gl.glPushMatrix();//start all
        gl.glTranslatef(0f, 0.2f, 0f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.5f, 0.5f, 0f);
        //gl.glColor3f(0.901f, 0.901f, 0.909f);
        //gl.glColor3f(0.643f, 0.647f, 0.662f);
        gl.glColor3f(2/255f, 56/255f, 80/255f);
        glut.glutSolidOctahedron() ;//object
        gl.glPopMatrix();
        
        //---------------------------------------
        
        //------------------------------------------------------
        gl.glPopMatrix();
    
            
    }
    
    public void window(GLUT glut, GL gl){
    
        gl.glPushMatrix();//start all
        gl.glTranslatef(0f, 0f, 0f);
        //gl.glRotatef(-120, 0, 1, 0);
        //gl.glScalef(0.2f, 0.2f, 0.2f);
        //----------------------------------------------------------
        
        gl.glPushMatrix();//start all
        gl.glTranslatef(0f, 0f, 0f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(1f, 1f, 0f);
        //gl.glColor3f(0.901f, 0.901f, 0.909f);
        //gl.glColor3f(0.643f, 0.647f, 0.662f);
        gl.glColor3f(2/255f, 56/255f, 80/255f);
        glut.glutSolidSphere(0.6, 20, 10);//object
        gl.glPopMatrix();
        
        //-------------------------------------
        
        gl.glPushMatrix();//start all
        gl.glTranslatef(0f, -0.8f, 0f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(1f, 1.1f, 0f);
        //gl.glColor3f(0.901f, 0.901f, 0.909f);
        //gl.glColor3f(0.643f, 0.647f, 0.662f);
        gl.glColor3f(2/255f, 56/255f, 80/255f);
        glut.glutSolidCube(1.2f);//object
        gl.glPopMatrix();
        
        //---------------------------------------
        
        
        
        
        
        //------------------------------------------------------
        gl.glPopMatrix();}
    public void windowframe(GLUT glut, GL gl){
    
        gl.glPushMatrix();//start all
        gl.glTranslatef(0f, 0f, 0f);
        //gl.glRotatef(-120, 0, 1, 0);
        //gl.glScalef(0.2f, 0.2f, 0.2f);
        //----------------------------------------------------------
        
        gl.glPushMatrix();//start all
        gl.glTranslatef(0f, 0f, 0f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(1f, 1f, 0f);
        //gl.glColor3f(0.901f, 0.901f, 0.909f);
        //gl.glColor3f(0.643f, 0.647f, 0.662f);
        gl.glColor3f(98/255f, 195/255f, 237/255f);
        glut.glutSolidSphere(0.6, 20, 10);//object
        gl.glPopMatrix();
        
        //-------------------------------------
        
        gl.glPushMatrix();//start all
        gl.glTranslatef(0f, -0.8f, 0f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(1f, 1.1f, 0f);
        //gl.glColor3f(0.901f, 0.901f, 0.909f);
        //gl.glColor3f(0.643f, 0.647f, 0.662f);
        gl.glColor3f(98/255f, 195/255f, 237/255f);
        glut.glutSolidCube(1.2f);//object
        gl.glPopMatrix();
        
        //---------------------------------------
        
        
        
        //------------------------------------------------------
        gl.glPopMatrix();}
    public void windowBig(GLUT glut, GL gl){
    
         gl.glPushMatrix();//start all
        gl.glTranslatef(0f, 0f, 0f);
        //gl.glRotatef(-120, 0, 1, 0);
        //gl.glScalef(0.2f, 0.2f, 0.2f);
        //----------------------------------------------------------
        
        gl.glPushMatrix();//start all
        gl.glTranslatef(0f, 0f, 0f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(1f, 1f, 0.1f);
        //gl.glColor3f(0.901f, 0.901f, 0.909f);
        //gl.glColor3f(0.643f, 0.647f, 0.662f);
        
        gl.glColor3f(2/255f, 56/255f, 80/255f);
        glut.glutSolidSphere(0.6, 20, 10);//object
        gl.glPopMatrix();
        
        //-------------------------------------
        
        gl.glPushMatrix();//start all
        gl.glTranslatef(0f, -0.9f, 0f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(1f, 1.2f, 0.05f);
        //gl.glColor3f(0.901f, 0.901f, 0.909f);
        //gl.glColor3f(0.643f, 0.647f, 0.662f);
        gl.glColor3f(2/255f, 56/255f, 80/255f);
        glut.glutSolidCube(1.2f);//object
        gl.glPopMatrix();
        
        //---------------------------------------
        
        
        gl.glPushMatrix();//start all
        gl.glTranslatef(0f, 0.2f, 0f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.5f, 0.5f, 0.07f);
        //gl.glColor3f(0.901f, 0.901f, 0.909f);
        //gl.glColor3f(0.643f, 0.647f, 0.662f);
        gl.glColor3f(2/255f, 56/255f, 80/255f);
        glut.glutSolidOctahedron() ;//object
        gl.glPopMatrix();
        
        //---------------------------------------
        
        //------------------------------------------------------
        gl.glPopMatrix();
     }
    public void windowBigFrame(GLUT glut, GL gl){
    
         gl.glPushMatrix();//start all
        gl.glTranslatef(0f, 0f, 0f);
        //gl.glRotatef(-120, 0, 1, 0);
        //gl.glScalef(0.2f, 0.2f, 0.2f);
        //----------------------------------------------------------
        
        gl.glPushMatrix();//start all
        gl.glTranslatef(0f, 0f, 0f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(1f, 1f, 0.1f);
        //gl.glColor3f(0.901f, 0.901f, 0.909f);
        //gl.glColor3f(0.643f, 0.647f, 0.662f);
        
        gl.glColor3f(98/255f, 195/255f, 237/255f);
        glut.glutSolidSphere(0.6, 20, 10);//object
        gl.glPopMatrix();
        
        //-------------------------------------
        
        gl.glPushMatrix();//start all
        gl.glTranslatef(0f, -0.9f, 0f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(1f, 1.2f, 0.05f);
        //gl.glColor3f(0.901f, 0.901f, 0.909f);
        //gl.glColor3f(0.643f, 0.647f, 0.662f);
        gl.glColor3f(98/255f, 195/255f, 237/255f);
        glut.glutSolidCube(1.2f);//object
        gl.glPopMatrix();
        
        //---------------------------------------
        
        
        gl.glPushMatrix();//start all
        gl.glTranslatef(0f, 0.2f, 0f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.5f, 0.5f, 0.07f);
        //gl.glColor3f(0.901f, 0.901f, 0.909f);
        //gl.glColor3f(0.643f, 0.647f, 0.662f);
        gl.glColor3f(98/255f, 195/255f, 237/255f);
        glut.glutSolidOctahedron() ;//object
        gl.glPopMatrix();
        
        //---------------------------------------
        
        //------------------------------------------------------
        gl.glPopMatrix();
     }
    public void MasjedOld(GLUT glut, GL gl){
    
    gl.glPushMatrix();
    
    gl.glTranslatef(2f, 0.0f, 0f);
    //gl.glRotatef(90, 0, 1, 0);
    gl.glScalef(0.5f, 0.5f, 0.5f);
    //------------------------------------all
    

    

    
    gl.glPushMatrix();
    //gl.glTranslatef(0f, 1.2f, -2.0f);
    //gl.glRotatef(90, 1, 0, 0);
    gl.glScalef(0.5f, 0.9f, 0.7f);
    buldingOld(glut, gl);
    gl.glPopMatrix();
    //----------------------------------------
    gl.glPushMatrix();
    gl.glTranslatef(0.15f, 0f, -0.2f);
    //gl.glRotatef(90, 1, 0, 0);
    gl.glScalef(0.6f, 0.6f, 0.6f);
    Qubba(glut, gl);
    gl.glPopMatrix();
    //----------------------------------------
        gl.glPushMatrix();
    gl.glTranslatef(0.2f, 0f, -0.5f);
    //gl.glRotatef(90, 1, 0, 0);
    gl.glScalef(0.6f, 0.6f, 0.6f);
    MethanaOld(glut, gl);
    gl.glPopMatrix();
    //----------------------------------------
    
    gl.glPopMatrix();//end all ---------------------------------
    
    
    
    }
    public void buldingOld(GLUT glut, GL gl){
    
    gl.glPushMatrix();//start all
    gl.glTranslatef(0f, -1.0f, 0.0f);
    //gl.glRotatef(40, 0, 1, 0);
    
    
    
    
    //bulding
    gl.glPushMatrix();
    
    gl.glEnable( GL_DEPTH_TEST );
    gl.glTranslatef(0f, 0.0f, -2f);
    //gl.glRotatef(angle, x, y, z);
    gl.glScalef(2.2f, 1.03f, 1.5f);
    gl.glColor3f(241/255f, 239/255f, 240/255f);
    
    glut.glutSolidCube(2);//thing
    
    gl.glPopMatrix();//end 1
    

        
        gl.glPushMatrix();
        gl.glTranslatef(0f, 0f, 0f);
        //gl.glRotatef(-60, 0, 1, 1);
        //gl.glScalef(0.3f, 0.3f, 0f);
        // start all windows infront
        
       //window1
        gl.glPushMatrix();
        gl.glTranslatef(1.5f, 0.5f, -0.4f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.5f, 0.3f, 0f);
        window(glut, gl);
        gl.glPopMatrix();
        //---------------------------
        

        //window3
        gl.glPushMatrix();
        gl.glTranslatef(0.5f, 0.5f, -0.4f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.5f, 0.3f, 0f);
        window(glut, gl);
        gl.glPopMatrix();
        //---------------------------
        

        //window5
        gl.glPushMatrix();
        gl.glTranslatef(-0.5f, 0.5f, -0.4f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.5f, 0.3f, 0f);
        window(glut, gl);
        gl.glPopMatrix();
        //---------------------------
        

        //window7
        gl.glPushMatrix();
        gl.glTranslatef(-1.5f, 0.5f, -0.4f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.5f, 0.3f, 0f);
        window(glut, gl);
        gl.glPopMatrix();
        //---------------------------

        gl.glPopMatrix();
        // end windows infront -----------------------------------------
        
        
        
        
    //entrance1
    gl.glPushMatrix();
    gl.glTranslatef(0.0f, -0.5f, -0.4f);
    //gl.glRotatef(angle, x, y, z);
    gl.glScalef(1.3f, 1f, 0.3f);
    //gl.glColor3f(0.901f, 0.901f, 0.909f);
    gl.glColor3f(0.643f, 0.647f, 0.662f);
    
    glut.glutSolidCube(1);//thing
    
    gl.glPopMatrix();//----end 2
    //--------------------------------------------------------
    
    //door
    
        gl.glPushMatrix();//start all
        gl.glTranslatef(0f, -0.3f, -0.24f);
        //gl.glRotatef(-60, 0, 1, 1);
        gl.glScalef(0.6f, 0.4f, 0.1f);
        door(glut, gl);
        gl.glPopMatrix();
        
    //----------------------------------------------
    
    gl.glPopMatrix();//end all
    }
    public void MethanaOld(GLUT glut, GL gl){
    
    gl.glPushMatrix();//start all
    gl.glTranslatef(-1.3f, 2.4f, -1.8f);
    //gl.glRotatef(-60, 0, 1, 1);
    gl.glScalef(0.2f, 0.2f, 0.2f);
    
    
    gl.glPushMatrix();
    gl.glTranslatef(0f, 2f, -2.0f);
    //gl.glRotatef(90, 1, 0, 0);
    
    
    
    //cylinder
    gl.glPushMatrix();
    gl.glTranslatef(-2f, 0f, -2.0f);
    gl.glRotatef(90, 1, 0, 0);
    //gl.glScalef(1, 1.7f, 1);
    gl.glColor3f(0.643f, 0.647f, 0.662f);
        
    glut.glutSolidCylinder(0.05, 0.3, 20, 20);//thing
    gl.glPopMatrix();//----end 1
    
    //cylinder
    gl.glPushMatrix();
    gl.glTranslatef(-2f, -0.3f, -2.0f);
    gl.glRotatef(90, 1, 0, 0);
    //gl.glScalef(1, 1.7f, 1);
    gl.glColor3f(0.643f, 0.647f, 0.662f);
        
    glut.glutSolidCylinder(0.1, 5, 20, 20);//thing
    gl.glPopMatrix();//----end 2
    
    //sphere
    gl.glPushMatrix();
    gl.glTranslatef(-2f, -2f, -2f);
    //gl.glScalef(1f, 1f, 1f);
    gl.glColor3f(1f, 0.741f, 0.2f);
    //gl.glRotatef(angle, x, y, z);
    
    glut.glutSolidSphere(1.4f,20,20);//thing
    
    gl.glPopMatrix();//end 3
    
    
    gl.glPopMatrix();
 
    //-------------------------------------------------------
    
    
    gl.glPushMatrix();//start all
    gl.glTranslatef(-2f, 0f, -2f);
    //gl.glRotatef(angle, 0, 0, 0);
    //gl.glScalef(0.2f, 0.2f, 0.2f);
    //cylinder
    gl.glPushMatrix();
    gl.glTranslatef(0f, -1f, -2.0f);
    gl.glRotatef(90, 1, 0, 0);
    //gl.glScalef(1, 1.7f, 1);
    gl.glColor3f(0.643f, 0.647f, 0.662f);
        
    glut.glutSolidCylinder(1, 2, 10, 5);//thing
    
    
    gl.glPopMatrix();//----end 1
    
    //-------------------------------------------------------
    
    //cylinder
    gl.glPushMatrix();
    gl.glTranslatef(0f, -3.5f, -2.0f);
    gl.glRotatef(90, 1, 0, 0);
    //gl.glScalef(1, 1.7f, 1);
    gl.glColor3f(0.643f, 0.647f, 0.662f);
        
    glut.glutSolidTorus(0.5, 2, 3, 20);//thing
    
    
    gl.glPopMatrix();//----end 2
    
    
    //-------------------------------------------------------
    
    //cylinder
    gl.glPushMatrix();
    gl.glTranslatef(0f, -4.0f, -2.0f);
    gl.glRotatef(90, 1, 0, 0);
    //gl.glScalef(1, 1.7f, 1);
    gl.glColor3f(0.643f, 0.647f, 0.662f);
        
    glut.glutWireCylinder(1.3f, 3, 8, 0);//thing Wire object
    
    
    gl.glPopMatrix();//----end 3
    
    //-------------------------------------------------------
    
    //-------------------------------------------------------

    
    //cylinder
    gl.glPushMatrix();
    gl.glTranslatef(0f, -7.0f, -2.0f);
    gl.glRotatef(90, 1, 0, 0);
    //gl.glScalef(1, 1.7f, 1);
    gl.glColor3f(0.643f, 0.647f, 0.662f);
        
    glut.glutSolidCylinder(1.7, 5, 10, 5);//thing
    
    
    gl.glPopMatrix();//----end 5
    
    gl.glPopMatrix();//end cylinder
    
    gl.glPopMatrix();//end all
    
    
    }
    public static void lamp(GL gl, GLUT glut) {
        gl.glPushMatrix();

        // first blue cylinder
        gl.glPushMatrix();
        gl.glRotatef(90, 1, 0, 0);
        gl.glColor3f(67 / 255f, 116 / 255f, 130 / 255f); //dark blue
        glut.glutSolidCylinder(0.2, 4, 5, 20);
        gl.glPopMatrix();

        // second white cylinder
        gl.glTranslatef(0, 1, 0);
        gl.glPushMatrix();
        gl.glRotatef(90, 1, 0, 0);
        gl.glColor3f(1, 1, 1); //white
        glut.glutSolidCylinder(0.1, 1, 5, 20);
        gl.glPopMatrix();

        // lamp
        gl.glTranslatef(0, 0, 0);
        gl.glColor3f(224 / 255f, 198 / 255f, 101 / 255f); //yellow
        glut.glutSolidSphere(0.5, 10, 10);

        gl.glPopMatrix();
    }
    public void cloud1(GLUT glut, GL gl) {
        gl.glPushMatrix();
        gl.glColor3f(1, 1, 1); //white
        glut.glutSolidCube(1);
        gl.glTranslatef(1, 0, 0);
        glut.glutSolidCube(1);
        gl.glTranslatef(1, 0, 0);
        glut.glutSolidCube(1);
        gl.glTranslatef(-0.5f, 1, 0);
        glut.glutSolidCube(1);
        gl.glTranslatef(-1f, 0, 0);
        glut.glutSolidCube(1);
        gl.glPopMatrix();
    }
    public void cloud2(GLUT glut, GL gl) {
        gl.glPushMatrix();
        gl.glColor3f(1, 1, 1); //white
        gl.glScalef(2, 1, 1);
        glut.glutSolidCube(1);
        gl.glTranslatef(1, 0, 0);
        glut.glutSolidCube(1);
        gl.glTranslatef(1, 0, 0);
        glut.glutSolidCube(1);
        gl.glTranslatef(-0.5f, 1, 0);
        glut.glutSolidCube(1);
        gl.glTranslatef(-1f, 0, 0);
        glut.glutSolidCube(1);
        gl.glTranslatef(0.5f, 1, 0);
        glut.glutSolidCube(1);
        gl.glPopMatrix();
    }
    public void SolarLandscape(GLUT glut, GL gl){
    
    gl.glPushMatrix();
    gl.glTranslatef(0f, 0f, 0f);
    gl.glRotatef(90, 0, 1, 0);
    //gl.glScalef(0.2f, 0.2f, 0.2f);
    //----------------------- start all
    
    gl.glPushMatrix();
    //gl.glTranslatef(0f, -0.5f, 0f);
    //gl.glRotatef(-40, 0, 1, 1);
    //gl.glScalef(0.2f, 1f, 1.2f);
    plate(glut, gl);// end 1 ----------------
    gl.glPopMatrix();
    
    //pipe
    gl.glPushMatrix();
    gl.glTranslatef(0f, -0.5f, 0f);
    gl.glRotatef(90, 1, 0, 0);
    gl.glScalef(0.2f, 1f, 1.2f);
    gl.glColor3f(182/255f, 182/255f, 182/255f);
        
    glut.glutSolidCylinder(0.06,0.25,50,50);//thing
    
    gl.glPopMatrix();//----end 2----------------
    
    //base
    gl.glPushMatrix();
    gl.glTranslatef(0f, -0.81f, 0f);
    gl.glRotatef(90, 1, 0, 0);
    gl.glScalef(0.2f, 20f, 20f);
    gl.glColor3f(167/255f, 167/255f, 167/255f);
        
    glut.glutSolidCylinder(0.15,0.1,50,50);//thing
    
    gl.glPopMatrix();//----end 3----------------
    
    //-------------------------------------------------------
    
    
    gl.glPopMatrix();//---------------------end all
    
    
    }
    
    public void SolarPortrait(GLUT glut, GL gl){
    
    gl.glPushMatrix();
    gl.glTranslatef(2f, 0f, 0f);
    gl.glRotatef(90, 0, 1, 0);
    //gl.glScalef(0.2f, 0.2f, 0.2f);
    //----------------------- start all
    
    
    //cube
    gl.glPushMatrix();
    gl.glTranslatef(0f, -0.3f, 0.5f);
    //gl.glRotatef(90, 0, 1, 0);
    gl.glScalef(0.1f, 0.1f, 1.3f);
    gl.glColor3f(182/255f, 182/255f, 182/255f);
        
    glut.glutSolidCube(1f);//thing
    
    gl.glPopMatrix();//----end 1----------------
    
    //cube
    gl.glPushMatrix();
    gl.glTranslatef(0f, -0.9f, 0.5f);
    //gl.glRotatef(90, 0, 1, 0);
    gl.glScalef(0.1f, 0.1f, 1.3f);
    gl.glColor3f(182/255f, 182/255f, 182/255f);
        
    glut.glutSolidCube(1f);//thing
    
    gl.glPopMatrix();//----end 1----------------
    
    gl.glPushMatrix();
    gl.glTranslatef(0f, -0.5f, 0f);
    gl.glRotatef(90, 1, 0, 0);
    gl.glScalef(0.03f, 0.5f, 1f);
    plate(glut, gl);// end 1 ----------------
    gl.glPopMatrix();
    
    gl.glPushMatrix();
    gl.glTranslatef(0f, -0.5f, 0.6f);
    gl.glRotatef(90, 1, 0, 0);
    gl.glScalef(0.03f, 0.5f, 1f);
    plate(glut, gl);// end 1 ----------------
    gl.glPopMatrix();
    
    gl.glPushMatrix();
    gl.glTranslatef(0f, -0.5f, 1.2f);
    gl.glRotatef(90, 1, 0, 0);
    gl.glScalef(0.03f, 0.5f, 1f);
    plate(glut, gl);// end 1 ----------------
    gl.glPopMatrix();
    
    gl.glPushMatrix();
    gl.glTranslatef(0f, -0.6f, 0.6f);
    //pipe
    gl.glPushMatrix();
    gl.glTranslatef(0f, -0.5f, 0f);
    gl.glRotatef(90, 1, 0, 0);
    gl.glScalef(1f, 1f, 1.2f);
    gl.glColor3f(182/255f, 182/255f, 182/255f);
        
    glut.glutSolidCylinder(0.06,0.2,50,50);//thing
    
    gl.glPopMatrix();//----end 2----------------
    
    //base
    gl.glPushMatrix();
    gl.glTranslatef(0f, -0.71f, 0f);
    gl.glRotatef(90, 1, 0, 0);
    gl.glScalef(1f, 1f, 1.2f);
    gl.glColor3f(167/255f, 167/255f, 167/255f);
        
    glut.glutSolidCylinder(0.25,0.1,50,50);//thing
    
    gl.glPopMatrix();//----end 3----------------
    gl.glPopMatrix();
    
    
    
    //-------------------------------------------------------
    
    
    gl.glPopMatrix();//---------------------end all
    
    
    }
    
    public static void grid(GLUT glut, GL gl){
        
    //cylinder
    gl.glPushMatrix();
    gl.glTranslatef(0.1f, 0f, 0.1f);
    gl.glRotatef(-90, 0, 1, 0);
    gl.glScalef(1f, 1f, 1f);
    gl.glColor3f(182/255f, 182/255f, 182/255f);
    //----------------------- start grid
    
    gl.glPushMatrix();
    gl.glTranslatef(0.0f, 0.5f, 0);
    gl.glRotatef(90, 1, 0, 0);
    //gl.glScalef(1, 1.7f, 1);
    
        
    glut.glutWireCylinder(0.1, 1, 2, 8);//thing
    
    
    gl.glPopMatrix();//----end 1
    
    gl.glPushMatrix();
    gl.glTranslatef(0.2f, 0.5f, 0);
    gl.glRotatef(90, 1, 0, 0);
    //gl.glScalef(1, 1.7f, 1);
    
        
    glut.glutWireCylinder(0.1, 1, 2, 8);//thing
    
    
    gl.glPopMatrix();//----end 2
    
    //cylinder
    gl.glPushMatrix();
    gl.glTranslatef(0.4f, 0.5f, 0);
    gl.glRotatef(90, 1, 0, 0);
    //gl.glScalef(1, 1.7f, 1);
    
        
    glut.glutWireCylinder(0.1, 1, 2, 8);//thing
    gl.glPopMatrix();//----end 3
    
    gl.glPushMatrix();
    gl.glTranslatef(-0.2f, 0.5f, 0);
    gl.glRotatef(90, 1, 0, 0);
    //gl.glScalef(1, 1.7f, 1);
    
        
    glut.glutWireCylinder(0.1, 1, 2, 8);//thing
    gl.glPopMatrix();//----end 4
    
    gl.glPushMatrix();
    gl.glTranslatef(-0.4f, 0.5f, 0);
    gl.glRotatef(90, 1, 0, 0);
    //gl.glScalef(1, 1.7f, 1);
    
        
    glut.glutWireCylinder(0.1, 1, 2, 8);//thing
    
    
    gl.glPopMatrix();//----end 5
    
    //cylinder
    gl.glPushMatrix();
    gl.glTranslatef(-0.6f, 0.5f, 0);
    gl.glRotatef(90, 1, 0, 0);
    //gl.glScalef(1, 1.7f, 1);
    
        
    glut.glutWireCylinder(0.1, 1, 2, 8);//thing
    
    
    gl.glPopMatrix();//----end 6
    
    
    gl.glPopMatrix();//----end Grid
    
    
    
    
    }
    
    public static void plate(GLUT glut, GL gl){
    
    gl.glPushMatrix();
    gl.glEnable( GL_DEPTH_TEST );
    gl.glTranslatef(0f, 0f, 0f);
    //gl.glRotatef(90, 0, 1, 0);
    //gl.glScalef(0.2f, 0.2f, 0.2f);
    //----------------------- start all
    
    //cube
    gl.glPushMatrix();
    gl.glTranslatef(0f, 0f, 0f);
    //gl.glRotatef(90, 0, 1, 0);
    gl.glScalef(4f, 1f, 1.2f);
    gl.glColor3f(182/255f, 182/255f, 182/255f);
        
    glut.glutSolidCube(1f);//thing
    
    gl.glPopMatrix();//----end 1----------------

   //cube
    gl.glPushMatrix();
    gl.glTranslatef(2f, 0f, 0f);
    //gl.glRotatef(90, 0, 1, 0);
    gl.glScalef(0.2f, 1f, 1.2f);
    gl.glColor3f(0f, 0f, 125f);
        
    glut.glutSolidCube(0.9f);//thing
    
    gl.glPopMatrix();//----end 1----------------
    
    gl.glTranslatef(2.5f, 0f, 0f);
    //gl.glRotatef(-90, 0, 1, 0);
    //gl.glScalef(1f, 1f, 1.04f);
    grid(glut, gl);//grid end 2 ----------------
    
    gl.glPopMatrix();//----------------end
    
    
    }
    
     
    
    
    
    public void displayChanged(GLAutoDrawable drawable, boolean modeChanged, boolean deviceChanged) {
    }

    public void keyTyped(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void keyPressed(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void keyReleased(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

